package org.jtrim.image.transform;

public enum ZoomToFitOption {
    KeepAspectRatio,
    MayMagnify,
    FitWidth,
    FitHeight
}
