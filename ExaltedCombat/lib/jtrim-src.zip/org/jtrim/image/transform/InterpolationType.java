/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jtrim.image.transform;

/**
 *
 * @author Kelemen Attila
 */
public enum InterpolationType {
    NEAREST_NEIGHBOR,
    BILINEAR,
    BICUBIC
}
