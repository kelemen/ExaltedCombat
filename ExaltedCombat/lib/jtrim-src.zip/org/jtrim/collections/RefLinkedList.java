/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jtrim.collections;

import java.util.*;
import org.jtrim.collections.RefList.ElementRef;

/**
 *
 * @author Kelemen Attila
 */
public final class RefLinkedList<E>
extends
        AbstractSequentialList<E>
implements
        RefList<E>, Deque<E> {

    private static final String REMOVED_REF
            = "The reference was detached from the list.";

    private class LinkedRef implements ElementRef<E> {
        private E element;
        private LinkedRef prev;
        private LinkedRef next;

        private LinkedRef(E element) {
            this.element = element;
        }

        @Override
        public int getIndex() {
            assert this != head && this != tail
                    : "The head and the tail element does not have an index.";

            if (isRemoved()) {
                throw new IllegalStateException(REMOVED_REF);
            }

            int index = 0;
            LinkedRef currentRef = prev;
            while (currentRef != head) {
                currentRef = currentRef.prev;
                index++;
            }

            return index;
        }

        @Override
        public void setElement(E newElement) {
            assert this != head && this != tail
                    : "The head and tail of the list cannot have an element.";

            element = newElement;
        }

        @Override
        public E getElement() {
           assert this != head && this != tail
                    : "The head and tail of the list cannot have an element.";

            return element;
        }

        @Override
        public ListIterator<E> getIterator() {
            if (!isRemoved()) {
                return new ReferenceIterator(this);
            }
            else {
                throw new IllegalStateException(REMOVED_REF);
            }
        }

        @Override
        public boolean hasNext() {
            return next != tail && next != null;
        }

        @Override
        public boolean hasPrevious() {
            return prev != head && prev != null;
        }

        @Override
        public LinkedRef getNext() {
            return next != tail ? next : null;
        }

        @Override
        public LinkedRef getPrevious() {
            return prev != head ? prev : null;
        }

        @Override
        public void moveLast() {
            if (!isRemoved()) {
                if (next != tail) {
                    // detach
                    next.prev = prev;
                    prev.next = next;

                    // insert
                    prev = tail.prev;
                    next = tail;

                    tail.prev = this;
                }
            }
            else {
                throw new IllegalStateException(REMOVED_REF);
            }
        }

        @Override
        public void moveFirst() {
            if (!isRemoved()) {
                if (prev != head) {
                    // detach
                    next.prev = prev;
                    prev.next = next;

                    // insert
                    prev = head;
                    next = head.next;

                    head.next = this;
                }
            }
            else {
                throw new IllegalStateException(REMOVED_REF);
            }
        }

        @Override
        public void moveBackward() {
            if (!isRemoved()) {
                if (prev == head) {
                    throw new IllegalStateException("Cannot move backward because the element is already in the first position");
                }
                else {
                    LinkedRef prevRef = prev;
                    // detach
                    next.prev = prevRef;
                    prevRef.next = next;

                    // insert
                    prev = prevRef.prev;
                    next = prevRef;
                }
            }
            else {
                throw new IllegalStateException(REMOVED_REF);
            }
        }

        @Override
        public void moveForward() {
            if (!isRemoved()) {
                if (next == tail) {
                    throw new IllegalStateException("Cannot move backward because the element is already in the last position");
                }
                else {
                    LinkedRef nextRef = next;
                    // detach
                    prev.next = nextRef;
                    nextRef.prev = prev;

                    // insert
                    prev = nextRef;
                    next = nextRef.next;
                }
            }
            else {
                throw new IllegalStateException(REMOVED_REF);
            }
        }

        @Override
        public LinkedRef addAfter(E newElement) {
            LinkedRef newRef = new LinkedRef(newElement);

            newRef.next = next;
            newRef.prev = this;

            next.prev = newRef;
            next = newRef;

            size++;

            return newRef;
        }

        @Override
        public LinkedRef addBefore(E newElement) {
            LinkedRef newRef = new LinkedRef(newElement);

            newRef.next = this;
            newRef.prev = prev;

            prev.next = newRef;
            prev = newRef;

            size++;

            return newRef;
        }

        private boolean checkConsistency() {
            return (next != null && prev != null) || (next == prev);
        }

        @Override
        public boolean isRemoved() {
            assert this != head && this != tail
                    : "isRemoved() is not defined on the head and tail of the list.";

            assert checkConsistency()
                    : "Either next and previous element must be null or neither of them.";

            return next == null;
        }

        @Override
        public void remove() {
            assert this != head && this != tail
                    : "The head and the tail of the list cannot be removed.";

            if (!isRemoved()) {
                prev.next = next;
                next.prev = prev;

                prev = null;
                next = null;

                size--;
            }
        }
    }

    private int size;
    private final LinkedRef head;
    private final LinkedRef tail;

    public RefLinkedList() {
        head = new LinkedRef(null);
        tail = new LinkedRef(null);

        head.prev = null;
        head.next = tail;

        tail.prev = head;
        tail.next = null;
    }

    public RefLinkedList(Collection<? extends E> collection) {
        head = new LinkedRef(null);
        tail = new LinkedRef(null);

        head.prev = null;
        head.next = tail;

        tail.prev = head;
        tail.next = null;

        addAll(collection);
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    private ElementRef<E> findRawFirstReference(Object o) {
        for (LinkedRef element = head.next; element != tail; element = element.next) {
            E currentElement = element.element;

            if (o == currentElement || o.equals(currentElement)) {
                return element;
            }
        }

        return null;
    }

    private ElementRef<E> findRawLastReferece(Object o) {
        for (LinkedRef element = tail.prev; element != head; element = element.prev) {
            E currentElement = element.element;

            if (o == currentElement || o.equals(currentElement)) {
                return element;
            }
        }

        return null;
    }

    @Override
    public ElementRef<E> findFirstReference(E o) {
        return findRawFirstReference(o);
    }

    @Override
    public ElementRef<E> findLastReferece(E o) {
        return findRawLastReferece(o);
    }

    @Override
    public ElementRef<E> findReference(E element) {
        return findFirstReference(element);
    }

    @Override
    public ElementRef<E> getFirstReference() {
        LinkedRef result = head.next;
        if (result == tail) {
            result = null;
        }

        return result;
    }

    @Override
    public ElementRef<E> getLastReference() {
        LinkedRef result = tail.prev;
        if (result == head) {
            result = null;
        }

        return result;
    }

    @Override
    public ElementRef<E> getReference(int index) {
        return getInternalRef(index);
    }

    private LinkedRef getInternalRef(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException(index + " is not within [0, " + (size - 1) + "]");
        }

        LinkedRef result;

        if (index < size / 2) {
            result = head;
            for (int i = 0; i <= index; i++) {
                result = result.next;
            }
        }
        else {
            result = tail;
            for (int i = size; i > index; i--) {
                result = result.prev;
            }
        }

        return result;
    }

    @Override
    public boolean contains(Object o) {
        return findRawFirstReference(o) != null;
    }

    @Override
    public Iterator<E> iterator() {
        return new ReferenceIterator(head.next, 0);
    }

    @Override
    public boolean add(E e) {
        tail.addBefore(e);
        return true;
    }

    @Override
    public boolean remove(Object o) {
        ElementRef<E> ref = findRawFirstReference(o);

        if (ref != null) {
            ref.remove();
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public void clear() {
        size = 0;

        // We have to remove the references from the list
        // so even if someoneelse calls remove() on them it does not
        // corrupt this list.
        LinkedRef ref = head.next;
        while (ref != tail) {
            LinkedRef nextRef = ref.next;
            ref.next = null;
            ref.prev = null;
            ref = nextRef;
        }

        head.next = tail;
        tail.prev = head;
    }

    @Override
    public E get(int index) {
        return getInternalRef(index).element;
    }

    @Override
    public E set(int index, E element) {
        LinkedRef ref = getInternalRef(index);
        E oldValue = ref.element;
        ref.element = element;

        return oldValue;
    }

    @Override
    public ElementRef<E> addFirstGetReference(E element) {
        return head.addAfter(element);
    }

    @Override
    public ElementRef<E> addLastGetReference(E element) {
        return tail.addBefore(element);
    }

    @Override
    public ElementRef<E> addGetReference(E element) {
        return addLastGetReference(element);
    }

    @Override
    public ElementRef<E> addGetReference(int index, E element) {
        if (index == size) {
            return tail.addBefore(element);
        }
        else {
            return getReference(index).addBefore(element);
        }
    }

    @Override
    public void add(int index, E element) {
        addGetReference(index, element);
    }

    @Override
    public E remove(int index) {
        LinkedRef ref = getInternalRef(index);
        ref.remove();

        return ref.element;
    }

    @Override
    public ListIterator<E> listIterator() {
        return new ReferenceIterator(head.next, 0);
    }

    @Override
    public ListIterator<E> listIterator(int index) {
        return new ReferenceIterator(getInternalRef(index), index);
    }

    @Override
    public void addFirst(E e) {
        head.addAfter(e);
    }

    @Override
    public void addLast(E e) {
        tail.addBefore(e);
    }

    @Override
    public boolean offerFirst(E e) {
        head.addAfter(e);
        return true;
    }

    @Override
    public boolean offerLast(E e) {
        tail.addBefore(e);
        return true;
    }

    @Override
    public E removeFirst() {
        LinkedRef first = head.next;
        if (first != tail) {
            first.remove();
            return first.element;
        }
        else {
            throw new NoSuchElementException("The list is empty.");
        }
    }

    @Override
    public E removeLast() {
        LinkedRef last = tail.prev;
        if (last != head) {
            last.remove();
            return last.element;
        }
        else {
            throw new NoSuchElementException("The list is empty.");
        }
    }

    @Override
    public E pollFirst() {
        LinkedRef first = head.next;
        if (first != tail) {
            first.remove();
            return first.element;
        }
        else {
            return null;
        }
    }

    @Override
    public E pollLast() {
        LinkedRef last = tail.prev;
        if (last != head) {
            last.remove();
            return last.element;
        }
        else {
            return null;
        }
    }

    @Override
    public E getFirst() {
        LinkedRef first = head.next;
        if (first != tail) {
            return first.element;
        }
        else {
            throw new NoSuchElementException("The list is empty.");
        }
    }

    @Override
    public E getLast() {
        LinkedRef last = tail.prev;
        if (last != head) {
            return last.element;
        }
        else {
            throw new NoSuchElementException("The list is empty.");
        }
    }

    @Override
    public E peekFirst() {
        LinkedRef first = head.next;
        if (first != tail) {
            return first.element;
        }
        else {
            return null;
        }
    }

    @Override
    public E peekLast() {
        LinkedRef last = tail.prev;
        if (last != head) {
            return last.element;
        }
        else {
            return null;
        }
    }

    @Override
    @SuppressWarnings("element-type-mismatch")
    public boolean removeFirstOccurrence(Object o) {
        return remove(o);
    }

    @Override
    public boolean removeLastOccurrence(Object o) {
        ElementRef<E> ref = findRawLastReferece(o);
        if (ref != null) {
            ref.remove();
            return true;
        }
        else {
            return false;
        }
    }

    @Override
    public boolean offer(E e) {
        add(e);
        return true;
    }

    @Override
    public E remove() {
        return removeFirst();
    }

    @Override
    public E poll() {
        return pollFirst();
    }

    @Override
    public E element() {
        return getFirst();
    }

    @Override
    public E peek() {
        return peekFirst();
    }

    @Override
    public void push(E e) {
        addFirst(e);
    }

    @Override
    public E pop() {
        return removeFirst();
    }

    @Override
    public Iterator<E> descendingIterator() {
        return new DescItr<>(new ReferenceIterator(tail, size - 1));
    }

    private static class DescItr<T> implements Iterator<T> {
        private final ListIterator<T> listItr;

        public DescItr(ListIterator<T> listItr) {
            this.listItr = listItr;
        }

        @Override
        public boolean hasNext() {
            return listItr.hasPrevious();
        }

        @Override
        public T next() {
            return listItr.previous();
        }

        @Override
        public void remove() {
            listItr.remove();
        }

    }

    private class ReferenceIterator implements ListIterator<E> {
        private LinkedRef lastRef;
        private LinkedRef nextRef;
        private int nextIndex;

        public ReferenceIterator(LinkedRef startRef) {
            this.lastRef = null;
            this.nextRef = startRef;
            this.nextIndex = startRef != tail ? startRef.getIndex() : size();
        }

        public ReferenceIterator(LinkedRef startRef, int startIndex) {
            this.lastRef = null;
            this.nextRef = startRef;
            this.nextIndex = startIndex;

            assert (startRef == tail && startIndex == size()) || startIndex == startRef.getIndex();
        }

        @Override
        public boolean hasNext() {
            return nextRef != tail;
        }

        @Override
        public E next() {
            if (nextRef != tail) {
                lastRef = nextRef;
                nextRef = nextRef.next;
                nextIndex++;

                return lastRef.getElement();
            }
            else {
                throw new NoSuchElementException("Last element was reached.");
            }
        }

        @Override
        public boolean hasPrevious() {
            return nextRef.hasPrevious();
        }

        @Override
        public E previous() {
            if (hasPrevious()) {
                lastRef = nextRef.prev;
                nextRef = lastRef;
                nextIndex--;

                return lastRef.getElement();
            }
            else {
                throw new NoSuchElementException("First element was reached.");
            }
        }

        @Override
        public int nextIndex() {
            return nextIndex;
        }

        @Override
        public int previousIndex() {
            return nextIndex - 1;
        }

        @Override
        public void remove() {
            if (lastRef == null) {
                throw new IllegalStateException();
            }

            if (lastRef == nextRef) {
                nextRef = nextRef.prev;
                lastRef.remove();
            }
            else {
                lastRef.remove();
                nextIndex--;
            }

            lastRef = null;
        }

        @Override
        public void set(E e) {
            if (lastRef == null) {
                throw new IllegalStateException();
            }

            lastRef.element = e;
        }

        @Override
        public void add(E e) {
            nextRef.addBefore(e);
        }
    }
}
