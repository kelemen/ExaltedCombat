/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jtrim.collections;

import java.util.ListIterator;
import org.jtrim.collections.RefList.ElementRef;

/**
 * @see CollectionsEx#getDetachedListRef(java.lang.Object)
 *
 * @author Kelemen Attila
 */
class DetachedListRef<E> implements RefList.ElementRef<E> {
    private static final String NOT_IN_LIST = "The element is not in a list.";

    private E element;

    public DetachedListRef(E element) {
        this.element = element;
    }

    @Override
    public int getIndex() {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public ListIterator<E> getIterator() {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public boolean hasPrevious() {
        return false;
    }

    @Override
    public ElementRef<E> getNext() {
        return null;
    }

    @Override
    public ElementRef<E> getPrevious() {
        return null;
    }

    @Override
    public void moveLast() {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public void moveFirst() {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public void moveBackward() {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public void moveForward() {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public ElementRef<E> addAfter(E newElement) {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public ElementRef<E> addBefore(E newElement) {
        throw new IllegalStateException(NOT_IN_LIST);
    }

    @Override
    public void setElement(E newElement) {
        element = newElement;
    }

    @Override
    public E getElement() {
        return element;
    }

    @Override
    public boolean isRemoved() {
        return false;
    }

    @Override
    public void remove() {
    }
}
