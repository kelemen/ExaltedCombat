/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jtrim.collections;

import java.util.*;

/**
 *
 * @author Kelemen Attila
 */
public interface RefList<E> extends List<E>, RefCollection<E> {
    public static interface ElementRef<E> extends RefCollection.ElementRef<E> {
        public int getIndex();

        public ListIterator<E> getIterator();

        public boolean hasNext();
        public boolean hasPrevious();

        public ElementRef<E> getNext();
        public ElementRef<E> getPrevious();

        public void moveLast();
        public void moveFirst();

        public void moveBackward();
        public void moveForward();

        public ElementRef<E> addAfter(E newElement);
        public ElementRef<E> addBefore(E newElement);
    }

    public ElementRef<E> findFirstReference(E o);
    public ElementRef<E> findLastReferece(E o);

    public ElementRef<E> getFirstReference();
    public ElementRef<E> getLastReference();
    public ElementRef<E> getReference(int index);

    public ElementRef<E> addFirstGetReference(E element);
    public ElementRef<E> addLastGetReference(E element);
    public ElementRef<E> addGetReference(int index, E element);
}
