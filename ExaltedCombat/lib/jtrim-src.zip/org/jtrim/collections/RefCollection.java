package org.jtrim.collections;

import java.util.*;

/**
 *
 * @author Kelemen Attila
 */
public interface RefCollection<E> extends Collection<E> {
    public static interface ElementRef<E> {
        public void setElement(E newElement);
        public E getElement();

        public boolean isRemoved();
        public void remove();
    }

    public ElementRef<E> addGetReference(E element);
    public ElementRef<E> findReference(E element);
}
